from socket import *
import sys

hostname = '127.0.0.1'
serverPort = int(sys.argv[1])
print(f"\nIP address:{hostname}")
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind((hostname, serverPort))
serverSocket.listen(1)

while True:
    print("\nThe server is Ready...")
    connectionSocket, address = serverSocket.accept()
    try:
        request = connectionSocket.recv(1024).decode()
        requested_file = request.split()[1]
        file = open(requested_file[1:], 'rb')
        content = file.read()
        connectionSocket.send(b"HTTP/1.1 200 OK\r\n\r\n")
        connectionSocket.send(content)
        connectionSocket.close()

    except IOError:
        connectionSocket.send(b"HTTP/1.1 404 Not Found\r\n\r\n")
        connectionSocket.send(b"404 Not Found")
        connectionSocket.close()
